-- Tender Days — accounts & billing schema
-- Run this in Supabase → SQL Editor.

create table if not exists public.subscriptions (
  user_id                uuid primary key references auth.users(id) on delete cascade,
  email                  text,
  stripe_customer_id     text unique,
  stripe_subscription_id text unique,
  status                 text default 'none',   -- none | trialing | active | past_due | canceled | unpaid
  price_id               text,
  current_period_end     timestamptz,
  updated_at             timestamptz default now()
);

alter table public.subscriptions enable row level security;

-- Each user may READ only their own subscription row.
drop policy if exists "read own subscription" on public.subscriptions;
create policy "read own subscription"
  on public.subscriptions for select
  using (auth.uid() = user_id);

-- No INSERT/UPDATE/DELETE policies => the browser can never write here.
-- Only the Edge Functions (service_role key) write, and service_role bypasses RLS.

-- Create an empty subscription row automatically when a user signs up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.subscriptions (user_id, email, status)
  values (new.id, new.email, 'none')
  on conflict (user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
